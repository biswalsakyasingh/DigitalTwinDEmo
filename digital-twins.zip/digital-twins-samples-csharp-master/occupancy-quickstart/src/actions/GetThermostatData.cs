﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;


namespace Microsoft.Azure.DigitalTwins.Samples
{
    public static partial class Actions
    {
        public static async Task GetThermostatData(HttpClient httpClient)
        {
            var maxGets = 30;
            for (var curGets = 0; curGets < maxGets; ++curGets)
            {
                var (spaces, response) = await GetManagementItemsAsync<Models.Sensor>(httpClient, "sensors", "includes=values");

            }

            await Task.Delay(TimeSpan.FromSeconds(4));
        }

    }
}
