﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.Azure.DigitalTwins.Samples.models
{
    public class Blob
    {
        public string parentId { get; set; }
        public string name { get; set; }
        public string type { get; set; }
        public string subtype { get; set; }
        public string description { get; set; }
        public string sharing { get; set; }

    }
}
