﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Azure.DigitalTwins.Samples.Models;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;


namespace Microsoft.Azure.DigitalTwins.Samples
{
    public static partial class Actions
    {
        public static async Task GetThermostatData(HttpClient httpClient)
        {
            do
            {
                var (sensors, response) = await GetManagementItemsAsync<Models.Sensor>(httpClient, "sensors", "include=values");


                foreach (var sensor in sensors)
                {
                    var SensorResponse = await httpClient.GetAsync($"sensors/{sensor.Id}/value");
                    if (SensorResponse.IsSuccessStatusCode)
                    {
                        var content = await SensorResponse.Content.ReadAsStringAsync();
                        var sensorContent = JsonConvert.DeserializeObject<SpaceValue>(content);
                        Console.WriteLine("---------------------------------------------------------");
                        Console.WriteLine($"sensorContent.Type : {sensorContent.Type}");
                        Console.WriteLine($"sensorContent.Value: {sensorContent.Value}");

                        Console.WriteLine("------------------------------");
                        foreach (var historicalValues in sensorContent.HistoricalValues)
                        {
                            Console.WriteLine($"historicalValues.Value: {historicalValues.Value}");
                        }
                        Console.WriteLine("-----------------------------");

                        Console.WriteLine($"sensorContent.Timestamp :{sensorContent.Timestamp}");
                        Console.WriteLine("---------------------------------------------------------");
                    }
                }
                await Task.Delay(TimeSpan.FromSeconds(5));
            }
            while (true);
        }

    }
}
