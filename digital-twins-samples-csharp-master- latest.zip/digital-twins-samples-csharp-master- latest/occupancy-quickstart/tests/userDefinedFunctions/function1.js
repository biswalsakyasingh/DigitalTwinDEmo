function process(sensor, sensorReading) {
    log(`Processing function for ${sensor} with reading: ${sensorReading}.`);
}